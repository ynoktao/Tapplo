package com.sazemTapplo

import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class TableActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_table)

        val columnCount = intent.getIntExtra("COLUMN_COUNT", 1)
        val rowsContainer = findViewById<LinearLayout>(R.id.rowsContainer)
        val addButton = findViewById<Button>(R.id.addButton)

        val editTexts = mutableListOf<EditText>()

        for (i in 1..columnCount) {
            val editText = EditText(this)
            editText.hint = "Sütun $i"
            rowsContainer.addView(editText)
            editTexts.add(editText)
        }

        addButton.setOnClickListener {
            val filePath = Environment.getExternalStorageDirectory().path + "/Tapplo.xlsx"
            val file = File(filePath)
            val workbook = if (file.exists()) {
                val fileInputStream = FileInputStream(file)
                val wb = XSSFWorkbook(fileInputStream)
                fileInputStream.close()
                wb
            } else {
                XSSFWorkbook()
            }

            val sheet = if (workbook.numberOfSheets > 0) {
                workbook.getSheetAt(0)
            } else {
                workbook.createSheet("Sheet1")
            }

            val lastRowNum = sheet.lastRowNum
            val newRow = sheet.createRow(lastRowNum + 1)

            for (i in editTexts.indices) {
                val cell = newRow.createCell(i)
                cell.setCellValue(editTexts[i].text.toString())
            }

            val fileOut = FileOutputStream(file)
            workbook.write(fileOut)
            fileOut.close()
            workbook.close()
            finish()
        }
    }
}
